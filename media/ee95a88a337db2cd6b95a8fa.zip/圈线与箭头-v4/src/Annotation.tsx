import React, {useMemo} from 'react';
import {evolvePath, getLength, getPointAtLength} from '@remotion/paths';
import {AbsoluteFill, Easing, Img, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

export type AnnotationProps = {showLowerArrow: boolean};

// Both original annotations draw together, with only a three-frame offset
// at 60fps. Their movement overlaps for nearly the entire drawing interval.
const timing = {
  upperArrow: [0, 1.2],
  lowerArrow: [0.1, 1],
  circle: [3 / 60, 1.25],
} as const;

// A pronounced slow-fast-slow drawing gesture: zero initial/final velocity,
// concentrated travel in the middle, and no retraction of existing ink.
const drawEasing = Easing.bezier(0.68, 0, 0.32, 1);

// Reference coordinates: 1448 × 1086. Start at the top and draw clockwise.
const ellipse = 'M 476 352 C 620 352 793 370 862 394 C 891 405 909 424 883 441 C 834 470 642 484 473 483 C 278 482 115 474 67 451 C 22 431 62 405 129 389 C 219 366 350 354 476 352 C 483 352 491 352 499 352';
const upperArrow = 'M 1121 310 C 1103 326 1083 335 1063 344 C 1017 365 954 383 898 398';
const upperHeadA = 'M 898 398 L 907 376';
const upperHeadB = 'M 898 398 L 916 406';
const lowerArrow = 'M 96 572 C 64 577 35 551 36 520 C 36 496 53 475 81 467';
const lowerHeadA = 'M 81 467 L 61 465';
const lowerHeadB = 'M 81 467 L 70 484';

const upperSegmentLengths = [upperArrow, upperHeadA, upperHeadB].map(getLength);
const lowerSegmentLengths = [lowerArrow, lowerHeadA, lowerHeadB].map(getLength);

// One distance curve for the entire arrow; do not restart easing at every
// arrowhead stroke. The two wings are reached naturally during deceleration.
const arrowStrokeProgress = (lengths: number[], progress: number) => {
  const travelled = lengths.reduce((total, length) => total + length, 0) * progress;
  let completedLength = 0;
  return lengths.map((length) => {
    const localProgress = Math.max(0, Math.min(1, (travelled - completedLength) / length));
    completedLength += length;
    return localProgress;
  });
};

const brushContour = (path: string, width: number, seed: number) => {
  const length = getLength(path);
  const steps = Math.max(24, Math.ceil(length / 1.1));
  const sides: {x: number; y: number}[][] = [[], []];
  for (let i = 0; i <= steps; i++) {
    const distance = length * i / steps;
    const point = getPointAtLength(path, distance);
    const previous = getPointAtLength(path, Math.max(0, distance - 0.6));
    const next = getPointAtLength(path, Math.min(length, distance + 0.6));
    const dx = next.x - previous.x;
    const dy = next.y - previous.y;
    const norm = Math.hypot(dx, dy) || 1;
    const pressure = 0.9 + 0.13 * Math.sin(distance * 0.073 + seed) + 0.08 * Math.sin(distance * 0.33 + seed);
    const edgeNoise = 0.10 * Math.sin(distance * 2.7 + seed);
    const tipTaper = Math.min(1, 0.28 + distance / 6, 0.28 + (length - distance) / 5);
    const half = width * 0.5 * pressure * tipTaper;
    const drift = 0.12 * Math.sin(distance * 0.38 + seed);
    for (let side = 0; side < 2; side++) {
      const offset = (side === 0 ? 1 : -1) * (half + edgeNoise) + drift;
      sides[side].push({x: point.x - dy / norm * offset, y: point.y + dx / norm * offset});
    }
  }
  return [...sides[0], ...sides[1].reverse()].map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(3)} ${p.y.toFixed(3)}`).join(' ') + ' Z';
};

const GrowingMaskPath: React.FC<{path: string; progress: number; width?: number}> = ({path, progress, width = 16}) => progress <= 0 ? null : (
  <path d={path} {...(progress >= 1 ? {} : evolvePath(progress, path))} fill="none" stroke="white" strokeWidth={width} strokeLinecap="round" strokeLinejoin="round" />
);

const NewBrushStroke: React.FC<{id: string; path: string; progress: number; seed: number; width?: number}> = ({id, path, progress, seed, width = 2.7}) => {
  const contour = useMemo(() => brushContour(path, width, seed), [path, width, seed]);
  return (
    <g>
      <defs>
        <mask id={id} maskUnits="userSpaceOnUse" x="0" y="0" width="1448" height="1086">
          <GrowingMaskPath path={path} progress={progress} width={12} />
        </mask>
      </defs>
      <g mask={`url(#${id})`}>
        <path d={contour} fill="#f2edde" filter="url(#dry-ink)" />
        <path d={path} fill="none" stroke="#d2c8b2" strokeWidth="0.36" strokeDasharray="1.5 12 0.7 23 3 18" opacity="0.55" />
      </g>
    </g>
  );
};

export const HanddrawnAnnotation: React.FC<AnnotationProps> = ({showLowerArrow}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const time = frame / fps;
  const progress = (from: number, to: number) => interpolate(time, [from, to], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: drawEasing,
  });
  const [upperShaftProgress, upperHeadAProgress, upperHeadBProgress] = arrowStrokeProgress(
    upperSegmentLengths, progress(...timing.upperArrow),
  );
  const [lowerShaftProgress, lowerHeadAProgress, lowerHeadBProgress] = arrowStrokeProgress(
    lowerSegmentLengths, progress(...timing.lowerArrow),
  );

  return (
    <AbsoluteFill style={{backgroundColor: '#20211f'}}>
      {/* Ensure Remotion waits for the same bitmap resources used by the SVG masks. */}
      <Img src={staticFile('reference.png')} style={{position: 'absolute', width: 1, height: 1, opacity: 0}} />
      <Img src={staticFile('clean-background.png')} style={{position: 'absolute', width: 1, height: 1, opacity: 0}} />
      <svg viewBox="0 0 1448 1086" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
        <defs>
          {/* Replace only the old ink corridors. All other pixels remain original. */}
          <mask id="cleanup" maskUnits="userSpaceOnUse" x="0" y="0" width="1448" height="1086">
            {[ellipse, upperArrow, upperHeadA, upperHeadB].map((path, i) => <GrowingMaskPath key={i} path={path} progress={1} width={16} />)}
          </mask>
          <mask id="original-ink-reveal" maskUnits="userSpaceOnUse" x="0" y="0" width="1448" height="1086">
            <GrowingMaskPath path={ellipse} progress={progress(...timing.circle)} />
            <GrowingMaskPath path={upperArrow} progress={upperShaftProgress} />
            <GrowingMaskPath path={upperHeadA} progress={upperHeadAProgress} />
            <GrowingMaskPath path={upperHeadB} progress={upperHeadBProgress} />
          </mask>
          <filter id="dry-ink" x="-15%" y="-15%" width="130%" height="130%" colorInterpolationFilters="sRGB">
            <feTurbulence type="fractalNoise" baseFrequency="0.81" numOctaves="2" seed="29" result="paper-grain" />
            <feColorMatrix in="paper-grain" type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 1.8 -0.2" result="grain-alpha" />
            <feComposite in="SourceGraphic" in2="grain-alpha" operator="in" />
          </filter>
        </defs>
        <image href={staticFile('reference.png')} width="1448" height="1086" preserveAspectRatio="none" />
        <image href={staticFile('clean-background.png')} width="1448" height="1086" preserveAspectRatio="none" mask="url(#cleanup)" />
        {/* Grow a mask over the original strokes to retain their actual, fixed texture. */}
        <image href={staticFile('reference.png')} width="1448" height="1086" preserveAspectRatio="none" mask="url(#original-ink-reveal)" />
        {showLowerArrow && <g>
          <NewBrushStroke id="lower-shaft" path={lowerArrow} progress={lowerShaftProgress} seed={17} />
          <NewBrushStroke id="lower-head-a" path={lowerHeadA} progress={lowerHeadAProgress} seed={23} />
          <NewBrushStroke id="lower-head-b" path={lowerHeadB} progress={lowerHeadBProgress} seed={31} />
        </g>}
      </svg>
    </AbsoluteFill>
  );
};
