import "./index.css";
import {Composition} from 'remotion';
import {HanddrawnAnnotation} from './Annotation';

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition id="HanddrawnAnnotation" component={HanddrawnAnnotation}
        width={1448} height={1086} fps={60} durationInFrames={120}
        defaultProps={{showLowerArrow: false}} />
    </>
  );
};
