import {createEffect, type InteractivitySchema} from "remotion";

type RemoveCheckerboardBackgroundParams = {
  readonly cutoff?: number;
  readonly feather?: number;
  readonly chromaTolerance?: number;
};

const removeCheckerboardBackgroundSchema = {
  cutoff: {
    type: "number",
    min: 0,
    max: 255,
    step: 1,
    default: 246,
    description: "Background brightness cutoff",
  },
  feather: {
    type: "number",
    min: 1,
    max: 100,
    step: 1,
    default: 42,
    description: "Edge feather width",
  },
  chromaTolerance: {
    type: "number",
    min: 0,
    max: 80,
    step: 1,
    default: 12,
    description: "Neutral color tolerance",
  },
} as const satisfies InteractivitySchema;

const resolve = (params: RemoveCheckerboardBackgroundParams) => ({
  cutoff: params.cutoff ?? 246,
  feather: params.feather ?? 42,
  chromaTolerance: params.chromaTolerance ?? 12,
});

const smoothstep = (edge0: number, edge1: number, value: number) => {
  const normalized = Math.max(0, Math.min(1, (value - edge0) / (edge1 - edge0)));
  return normalized * normalized * (3 - 2 * normalized);
};

export const removeCheckerboardBackground = createEffect<
  RemoveCheckerboardBackgroundParams,
  null
>({
  type: "com.broll.removeCheckerboardBackground",
  label: "removeCheckerboardBackground()",
  documentationLink: null,
  backend: "2d",
  calculateKey: (params) => {
    const {cutoff, feather, chromaTolerance} = resolve(params);
    return `remove-checkerboard-${cutoff}-${feather}-${chromaTolerance}`;
  },
  setup: () => null,
  apply: ({source, target, width, height, params}) => {
    const context = target.getContext("2d");
    if (!context) {
      throw new Error("Could not create the checkerboard removal canvas.");
    }

    const {cutoff, feather, chromaTolerance} = resolve(params);
    context.clearRect(0, 0, width, height);
    context.drawImage(source, 0, 0, width, height);

    const imageData = context.getImageData(0, 0, width, height);
    const pixels = imageData.data;

    for (let index = 0; index < pixels.length; index += 4) {
      const red = pixels[index];
      const green = pixels[index + 1];
      const blue = pixels[index + 2];
      const brightest = Math.max(red, green, blue);
      const darkest = Math.min(red, green, blue);
      const chroma = brightest - darkest;
      const lightKey = smoothstep(cutoff - feather, cutoff, darkest);
      const neutralKey = 1 - smoothstep(chromaTolerance, chromaTolerance + 18, chroma);
      const keyStrength = lightKey * neutralKey;

      pixels[index + 3] = Math.round(pixels[index + 3] * (1 - keyStrength));
    }

    context.putImageData(imageData, 0, 0);
  },
  cleanup: () => undefined,
  schema: removeCheckerboardBackgroundSchema,
  validateParams: ({cutoff = 246, feather = 42, chromaTolerance = 12}) => {
    if (!Number.isFinite(cutoff) || cutoff < 0 || cutoff > 255) {
      throw new TypeError("cutoff must be between 0 and 255");
    }
    if (!Number.isFinite(feather) || feather < 1 || feather > 100) {
      throw new TypeError("feather must be between 1 and 100");
    }
    if (!Number.isFinite(chromaTolerance) || chromaTolerance < 0 || chromaTolerance > 80) {
      throw new TypeError("chromaTolerance must be between 0 and 80");
    }
  },
});
