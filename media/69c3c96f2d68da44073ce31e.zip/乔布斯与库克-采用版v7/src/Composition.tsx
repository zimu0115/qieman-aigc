import {blur} from "@remotion/effects/blur";
import {
  AbsoluteFill,
  CanvasImage,
  Composition,
  Easing,
  Interactive,
  interpolate,
  staticFile,
  useCurrentFrame,
} from "remotion";

export const MyComposition: React.FC = () => {
  return (
    <Composition
      id="JobsCookDocumentComparison"
      component={JobsCookDocumentComparison}
      durationInFrames={90}
      fps={30}
      width={1920}
      height={1080}
    />
  );
};

const JobsCookDocumentComparison: React.FC = () => {
  const frame = useCurrentFrame();

  return (
    <AbsoluteFill name="乔布斯与库克文档对比" style={{backgroundColor: "#d5d3d0"}}>
      <CanvasImage
        name="纸张纹理背景"
        src={staticFile("assets/01-background.png")}
        width={1920}
        height={1080}
        style={{position: "absolute", inset: 0, width: 1920, height: 1080}}
      />

      <Interactive.Div
        name="乔布斯文档"
        style={{
          position: "absolute",
          left: 334,
          top: 58,
          width: 594,
          height: 844,
          overflow: "hidden",
          borderRadius: 2,
          boxShadow: "0 18px 30px rgba(33, 28, 24, 0.24)",
          translate: interpolate(frame, [0, 45], ["0px 1050px", "0px 0px"], {
            easing: Easing.bezier(0.25, 0.75, 0.25, 1),
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          }),
        }}
      >
        <CanvasImage
          src={staticFile("assets/02-document-left.png")}
          width={780}
          height={983}
          style={{position: "absolute", left: -93, top: -58, width: 780, height: 983}}
        />
      </Interactive.Div>

      <Interactive.Div
        name="库克文档"
        style={{
          position: "absolute",
          left: 986,
          top: 58,
          width: 594,
          height: 844,
          overflow: "hidden",
          borderRadius: 2,
          boxShadow: "0 18px 30px rgba(33, 28, 24, 0.24)",
          translate: interpolate(frame, [3, 48], ["0px 1050px", "0px 0px"], {
            easing: Easing.bezier(0.25, 0.75, 0.25, 1),
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          }),
        }}
      >
        <CanvasImage
          src={staticFile("assets/03-document-right.png")}
          width={724}
          height={1001}
          style={{position: "absolute", left: -64, top: -84, width: 724, height: 1001}}
        />
      </Interactive.Div>

      <Interactive.Div
        name="乔布斯人物"
        style={{
          position: "absolute",
          left: -125,
          top: 345,
          width: 735,
          height: 735,
          translate: interpolate(frame, [6, 51], ["0px 780px", "0px 0px"], {
            easing: Easing.bezier(0.25, 0.75, 0.25, 1),
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          }),
        }}
      >
        <CanvasImage
          src={staticFile("assets/08-steve-jobs-sharp-transparent.png")}
          width={735}
          height={735}
					effects={[blur({radius: 19})]}
          style={{width: 735, height: 735}}
        />
      </Interactive.Div>

      <Interactive.Div
        name="库克人物"
        style={{
          position: "absolute",
					left: 1350,
          top: 300,
          width: 780,
          height: 780,
          translate: interpolate(frame, [9, 54], ["0px 820px", "0px 0px"], {
            easing: Easing.bezier(0.25, 0.75, 0.25, 1),
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          }),
        }}
      >
        <CanvasImage
          src={staticFile("assets/09-tim-cook-sharp-transparent.png")}
          width={780}
          height={780}
					effects={[blur({radius: 19})]}
          style={{width: 780, height: 780}}
        />
      </Interactive.Div>

      <Interactive.Div
        name="乔布斯姓名牌"
        style={{
          position: "absolute",
          left: 514,
          top: 914,
          width: 262,
          height: 99,
          overflow: "hidden",
          borderRadius: 7,
          boxShadow: "0 12px 20px rgba(35, 28, 22, 0.22)",
          translate: interpolate(frame, [12, 57], ["0px 220px", "0px 0px"], {
            easing: Easing.bezier(0.25, 0.75, 0.25, 1),
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          }),
        }}
      >
        <CanvasImage
          src={staticFile("assets/06-label-steve-jobs.png")}
          width={339}
          height={171}
          style={{position: "absolute", left: -33, top: -28, width: 339, height: 171}}
        />
      </Interactive.Div>

      <Interactive.Div
        name="库克姓名牌"
        style={{
          position: "absolute",
          left: 1142,
          top: 914,
          width: 250,
          height: 97,
          overflow: "hidden",
          borderRadius: 7,
          boxShadow: "0 12px 20px rgba(35, 28, 22, 0.22)",
          translate: interpolate(frame, [15, 60], ["0px 220px", "0px 0px"], {
            easing: Easing.bezier(0.25, 0.75, 0.25, 1),
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          }),
        }}
      >
        <CanvasImage
          src={staticFile("assets/07-label-tim-cook.png")}
          width={373}
          height={212}
          style={{position: "absolute", left: -49, top: -50, width: 373, height: 212}}
        />
      </Interactive.Div>
    </AbsoluteFill>
  );
};
