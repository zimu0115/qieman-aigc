import {Config} from '@remotion/cli/config';

Config.setRspack(false);
Config.setVideoImageFormat('png');
Config.setCodec('h264');
Config.setCrf(16);
Config.setOverwriteOutput(false);
