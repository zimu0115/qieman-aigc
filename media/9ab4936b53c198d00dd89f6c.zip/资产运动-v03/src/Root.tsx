import {Composition} from 'remotion';
import {S02AssetsMotion} from './S02AssetsMotion';

export const RemotionRoot = () => {
  return (
    <Composition
      id="S02AssetsMotion"
      component={S02AssetsMotion}
      width={1600}
      height={1200}
      fps={30}
      durationInFrames={150}
    />
  );
};
