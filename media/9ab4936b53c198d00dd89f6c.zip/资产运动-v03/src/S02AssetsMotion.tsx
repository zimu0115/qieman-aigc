import {
  AbsoluteFill,
  Easing,
  Freeze,
  Img,
  OffthreadVideo,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
} from 'remotion';

const clamp = {
  extrapolateLeft: 'clamp' as const,
  extrapolateRight: 'clamp' as const,
};

// 已在画面中的元素发生二次变化：先慢、后快、再慢，无回弹。
const secondaryMorphEasing = Easing.bezier(0.65, 0, 0.35, 1);

const getMorphProgress = (frame: number, startFrame: number) => {
  return interpolate(frame, [startFrame, startFrame + 45], [0, 1], {
    ...clamp,
    easing: secondaryMorphEasing,
  });
};

const mix = (from: number, to: number, progress: number) => {
  return from + (to - from) * progress;
};

const BackgroundVideo = () => {
  return (
    <OffthreadVideo
      src={staticFile('assets/视频背景素材-有条纹2.mp4')}
      muted
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        width: 1600,
        height: 1200,
        objectFit: 'contain',
      }}
    />
  );
};

const PlayingBackgroundVideo = () => {
  const localFrame = useCurrentFrame();

  return (
    <AbsoluteFill
      style={{
        opacity: interpolate(localFrame, [0, 15], [0, 1], {
          ...clamp,
          easing: secondaryMorphEasing,
        }),
      }}
    >
      <Freeze frame={90} active={localFrame >= 90}>
        <BackgroundVideo />
      </Freeze>
    </AbsoluteFill>
  );
};

export const S02AssetsMotion = () => {
  const frame = useCurrentFrame();

  // 每个单元素只计算一次进度；位移和缩小共同使用它，曲线绝对一致。
  const ziProgress = getMorphProgress(frame, 15);
  const chanProgress = getMorphProgress(frame, 17);

  return (
    <AbsoluteFill
      style={{backgroundColor: '#050505', overflow: 'hidden', isolation: 'isolate'}}
    >
      {/* 新增的无字黑石底图完整等比铺满4:3画布。 */}
      <Img
        src={staticFile('assets/image.png')}
        style={{position: 'absolute', left: 0, top: 0, width: 1600, height: 1200}}
      />

      {/* 渐显与视频播放在第30帧同时启动，转场期间视频持续运动。 */}
      <Sequence from={30} durationInFrames={120} premountFor={15}>
        <PlayingBackgroundVideo />
      </Sequence>

      <Img
        src={staticFile('assets/资.png')}
        style={{
          position: 'absolute',
          left: mix(180.8, 329.6, ziProgress),
          top: mix(93.8, 420, ziProgress),
          width: mix(433.3, 131.2, ziProgress),
          height: 'auto',
          mixBlendMode: 'color-dodge',
        }}
      />

      <Img
        src={staticFile('assets/产.png')}
        style={{
          position: 'absolute',
          left: mix(1028.2, 1156.4, chanProgress),
          top: mix(73.8, 398.6, chanProgress),
          width: mix(393.2, 135.5, chanProgress),
          height: 'auto',
          mixBlendMode: 'color-dodge',
        }}
      />

      <Img
        src={staticFile('assets/Assets..png')}
        style={{
          position: 'absolute',
          left: 703.3,
          top: 573.3,
          width: 189.6,
          height: 'auto',
        }}
      />
    </AbsoluteFill>
  );
};
