import {
  AbsoluteFill,
  Easing,
  Freeze,
  Img,
  OffthreadVideo,
  interpolate,
  staticFile,
  useCurrentFrame,
} from 'remotion';

const motion = {
  easing: Easing.bezier(0.25, 0.75, 0.25, 1),
  extrapolateLeft: 'clamp' as const,
  extrapolateRight: 'clamp' as const,
};

export const S02AssetsMotion = () => {
  const frame = useCurrentFrame();

  return (
    <AbsoluteFill style={{backgroundColor: '#050505', overflow: 'hidden'}}>
      <AbsoluteFill>
        <Freeze frame={42} active={(currentFrame) => currentFrame >= 42}>
          <OffthreadVideo
            src={staticFile('assets/视频背景素材-有条纹2.mp4')}
            muted
            style={{
              position: 'absolute',
              left: 0,
              top: 0,
              width: 1600,
              height: 1200,
              objectFit: 'contain',
            }}
          />
        </Freeze>
      </AbsoluteFill>

      {/* 先保持黑底0.5秒，再用0.9秒逐步显出真实视频素材。 */}
      <AbsoluteFill
        style={{
          backgroundColor: '#050505',
          opacity: interpolate(frame, [15, 42], [1, 0], motion),
        }}
      />

      {/* “资”使用完整透明PNG，从首帧位置等比缩至尾帧位置。 */}
      <Img
        src={staticFile('assets/资.png')}
        style={{
          position: 'absolute',
          left: interpolate(frame, [0, 31], [180.8, 329.6], motion),
          top: interpolate(frame, [0, 31], [93.8, 420], motion),
          width: interpolate(frame, [0, 31], [433.3, 131.2], {
            ...motion,
            output: 'perceptual-scale',
          }),
          height: 'auto',
        }}
      />

      {/* “产”晚2帧起步，同组运动明显重叠。 */}
      <Img
        src={staticFile('assets/产.png')}
        style={{
          position: 'absolute',
          left: interpolate(frame, [2, 33], [1028.2, 1156.4], motion),
          top: interpolate(frame, [2, 33], [73.8, 398.6], motion),
          width: interpolate(frame, [2, 33], [393.2, 135.5], {
            ...motion,
            output: 'perceptual-scale',
          }),
          height: 'auto',
        }}
      />

      {/* 英文标签在两个端点中保持相同位置和大小。 */}
      <Img
        src={staticFile('assets/Assets..png')}
        style={{
          position: 'absolute',
          left: 703.3,
          top: 573.3,
          width: 189.6,
          height: 'auto',
        }}
      />
    </AbsoluteFill>
  );
};
