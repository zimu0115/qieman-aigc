import {
  AbsoluteFill,
  Easing,
  Freeze,
  Img,
  OffthreadVideo,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
} from 'remotion';

const clamp = {
  extrapolateLeft: 'clamp' as const,
  extrapolateRight: 'clamp' as const,
};

// 已在画面中的元素发生二次变化：先慢、后快、再慢，无回弹。
const secondaryMorphEasing = Easing.bezier(0.65, 0, 0.35, 1);

const getMorphProgress = (frame: number, startFrame: number) => {
  return interpolate(frame, [startFrame, startFrame + 45], [0, 1], {
    ...clamp,
    easing: secondaryMorphEasing,
  });
};

const mix = (from: number, to: number, progress: number) => {
  return from + (to - from) * progress;
};

const BackgroundVideo = () => {
  return (
    <OffthreadVideo
      src={staticFile('assets/视频背景素材-有条纹2.mp4')}
      muted
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        width: 1600,
        height: 1200,
        objectFit: 'contain',
      }}
    />
  );
};

export const S02AssetsMotion = () => {
  const frame = useCurrentFrame();

  // 每个单元素只计算一次进度；位移和缩小共同使用它，曲线绝对一致。
  const ziProgress = getMorphProgress(frame, 15);
  const chanProgress = getMorphProgress(frame, 17);
  const videoReveal = interpolate(frame, [30, 45], [0, 1], {
    ...clamp,
    easing: secondaryMorphEasing,
  });

  return (
    <AbsoluteFill
      style={{backgroundColor: '#050505', overflow: 'hidden', isolation: 'isolate'}}
    >
      {/* 新增的无字黑石底图完整等比铺满4:3画布。 */}
      <Img
        src={staticFile('assets/image.png')}
        style={{position: 'absolute', left: 0, top: 0, width: 1600, height: 1200}}
      />

      {/* 文字运动开始0.5秒后，用0.5秒显出视频首帧。 */}
      <AbsoluteFill style={{opacity: frame < 58 ? videoReveal : 0}}>
        <Freeze frame={0}>
          <BackgroundVideo />
        </Freeze>
      </AbsoluteFill>

      {/* 约2秒处开始连续播放完整3秒素材，最后两帧固定。 */}
      <Sequence from={58} durationInFrames={92} premountFor={15}>
        <Freeze frame={90} active={(localFrame) => localFrame >= 90}>
          <BackgroundVideo />
        </Freeze>
      </Sequence>

      <Img
        src={staticFile('assets/资.png')}
        style={{
          position: 'absolute',
          left: mix(180.8, 329.6, ziProgress),
          top: mix(93.8, 420, ziProgress),
          width: mix(433.3, 131.2, ziProgress),
          height: 'auto',
          mixBlendMode: 'color-dodge',
        }}
      />

      <Img
        src={staticFile('assets/产.png')}
        style={{
          position: 'absolute',
          left: mix(1028.2, 1156.4, chanProgress),
          top: mix(73.8, 398.6, chanProgress),
          width: mix(393.2, 135.5, chanProgress),
          height: 'auto',
          mixBlendMode: 'color-dodge',
        }}
      />

      <Img
        src={staticFile('assets/Assets..png')}
        style={{
          position: 'absolute',
          left: 703.3,
          top: 573.3,
          width: 189.6,
          height: 'auto',
        }}
      />
    </AbsoluteFill>
  );
};
